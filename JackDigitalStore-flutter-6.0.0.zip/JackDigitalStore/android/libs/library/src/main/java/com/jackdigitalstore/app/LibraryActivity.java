package com.jackdigitalstore.app;

import android.app.*;
import android.os.*;

public class LibraryActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.library);
    }
}
