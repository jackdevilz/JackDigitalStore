import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:html_unescape/html_unescape.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:jackdigitalstore_app/provider/home_provider.dart';
import 'package:jackdigitalstore_app/screen/pages.dart';
import 'package:jackdigitalstore_app/utils/shared.dart';
import 'package:share_plus/share_plus.dart';

printLog(String message, {String? name}) {
  return log(message, name: name ?? 'log');
}

double responsiveFont(double designFont) {
  return ScreenUtil().setSp(designFont + 2);
}

convertDateFormatSlash(date) {
  String dateTime = DateFormat("dd/MM/yyyy").format(date);
  return dateTime;
}

buildNoAuth(context) {
  final imageNoLogin =
      Provider.of<HomeProvider>(context, listen: false).imageNoLogin;
  return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      imageNoLogin.image == null
          ? Icon(
              Icons.not_interested,
              color: primaryColor,
              size: 75,
            )
          : CachedNetworkImage(
              imageUrl: imageNoLogin.image!,
              height: MediaQuery.of(context).size.height * 0.4,
              placeholder: (context, url) => Container(),
              errorWidget: (context, url, error) => Icon(
                    Icons.not_interested,
                    color: primaryColor,
                    size: 75,
                  )),
      SizedBox(
        height: 10,
      ),
      Text(
        AppLocalizations.of(context)!.translate("pls_login_first")!,
        style: TextStyle(
          // color: Colors.black,
          fontWeight: FontWeight.w500, fontSize: 14,
        ),
        textAlign: TextAlign.center,
      ),
      SizedBox(
        height: 10,
      ),
      Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [accentColor, primaryColor])),
        height: 30.h,
        width: MediaQuery.of(context).size.width * 0.5,
        child: TextButton(
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => LoginScreen()));
          },
          child: Text(
            AppLocalizations.of(context)!.translate("login")!,
            style: TextStyle(
                color: Colors.white,
                fontSize: responsiveFont(10),
                fontWeight: FontWeight.w500),
          ),
        ),
      ),
    ],
  );
}

snackBar(context,
    {required String message,
    Color? color,
    int duration = 2,
    TextStyle? textStyle}) {
  final snackBar = SnackBar(
    content: Text(
      message,
      style: textStyle,
    ),
    backgroundColor: color != null ? color : null,
    duration: Duration(seconds: duration),
    behavior: SnackBarBehavior.floating,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10),
    ),
  );
  return ScaffoldMessenger.of(context).showSnackBar(snackBar);
}

customLoading({Color? color, double size = 20.0}) {
  final spinKit = SpinKitRotatingCircle(
    color: color != null ? color : accentColor,
    size: size,
  );
  return spinKit;
}

convertHtmlUnescape(String textCharacter) {
  var unescape = HtmlUnescape();
  var text = unescape.convert(textCharacter);
  return text;
}

shareLinks(String type, String? url) {
  return Share.share("Let's see our $type, click me $url !");
}
