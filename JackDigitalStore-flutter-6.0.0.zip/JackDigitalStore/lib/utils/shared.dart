import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_font_icons/flutter_font_icons.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:jackdigitalstore_app/model/product/product_model.dart';
import 'package:jackdigitalstore_app/provider/appnotifier_provider.dart';
import 'package:jackdigitalstore_app/provider/home_provider.dart';
import 'package:jackdigitalstore_app/provider/store_provider.dart';
import 'package:jackdigitalstore_app/provider/wishlist_provider.dart';
import 'package:jackdigitalstore_app/screen/pages.dart';
import 'package:jackdigitalstore_app/utils/currency_format.dart';
import 'package:jackdigitalstore_app/utils/utility.dart';
import 'package:jackdigitalstore_app/widget/marquee.dart';
import 'package:jackdigitalstore_app/widget/widget.dart';
import 'package:shimmer/shimmer.dart';
import 'package:uiblock/uiblock.dart';

part 'theme.dart';
part 'grid_list.dart';
