part of '../pages.dart';

class ForgotPasswordScreen extends StatefulWidget {
  final bool cek;
  final String? keys, id;

  const ForgotPasswordScreen({Key? key, this.cek = false, this.keys, this.id})
      : super(key: key);

  @override
  _ForgotPasswordScreenState createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  bool? isDone;
  TextEditingController email = new TextEditingController();
  AuthProvider? authProvider;

  sendEmail() {}

  @override
  void initState() {
    super.initState();
    authProvider = Provider.of<AuthProvider>(context, listen: false);
    if (widget.cek) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        context
            .read<AuthProvider>()
            .cekPasKey(context, id: widget.id, key: widget.keys);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context, listen: false);
    return Scaffold(
      // backgroundColor: Colors.white,
      appBar: AppBar(
        // backgroundColor: Colors.white,
        elevation: 5,
        shadowColor: Colors.grey.withOpacity(0.18),
        titleSpacing: 0,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.arrow_back,
            // color: Colors.black,
            size: 18,
          ),
        ),
        centerTitle: true,
        title: Text(
          AppLocalizations.of(context)!.translate('forgot_passwor')!,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            // color: Colors.black,
          ),
        ),
      ),
      body: Container(
        margin: EdgeInsets.symmetric(horizontal: 15, vertical: 20),
        child: Consumer<AuthProvider>(builder: (context, value, child) {
          return value.loadingCek
              ? customLoading()
              : Column(
                  children: [
                    //widget.cek! ? _showAlertDeleteConfirmation() : Container(),
                    Text(
                      isDone != true
                          ? AppLocalizations.of(context)!
                              .translate('lost_password')!
                          : AppLocalizations.of(context)!
                              .translate('we_have_sent')!,
                      style: TextStyle(
                        fontSize: isDone != true ? 14 : 16,
                      ),
                    ),
                    Container(height: 20),
                    isDone != true
                        ? Container(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                TextStyles(
                                  value: "Email",
                                  size: 14,
                                  weight: FontWeight.bold,
                                ),
                                Container(
                                  margin: EdgeInsets.only(top: 10),
                                  width: double.infinity,
                                  child: GreyText(
                                    hintText: "Enter your email",
                                    controllerTxt: email,
                                  ),
                                ),
                              ],
                            ),
                          )
                        : Container(),
                    Container(
                      width: double.infinity,
                      margin: EdgeInsets.symmetric(vertical: 15),
                      child: MaterialButton(
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(5))),
                        color: accentColor,
                        onPressed: () {
                          if (isDone != true) {
                            auth.forgotPassword(context, email: email.text);
                            setState(() {
                              isDone = true;
                            });
                          } else {
                            Navigator.pop(context);
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          child: Text(
                            isDone != true
                                ? AppLocalizations.of(context)!
                                    .translate('reset_pass')!
                                : AppLocalizations.of(context)!
                                    .translate('done')!,
                            style: TextStyle(color: primaryColor),
                          ),
                        ),
                      ),
                    ),
                  ],
                );
        }),
      ),
    );
  }

  _showAlertDeleteConfirmation() {
    SimpleDialog alert = SimpleDialog(
      contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 5),
      children: [
        Container(
          margin: EdgeInsets.symmetric(horizontal: 5),
          child: Column(
            children: [
              TextStyles(
                value: "Your link is expired",
                size: 16,
                weight: FontWeight.bold,
              ),
              SizedBox(height: 20),
              TextStyles(
                value: "Please resubmit your email again",
                size: 14,
                weight: FontWeight.bold,
                isLine: false,
              ),
              Container(
                margin: EdgeInsets.only(top: 15),
                child: Row(
                  children: [
                    Expanded(
                      child: MaterialButton(
                        color: accentColor,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5.0)),
                        elevation: 0,
                        height: 40,
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: TextStyles(
                          value: "Okay",
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
