import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:introduction_screen/introduction_screen.dart';
import 'package:provider/provider.dart';
import 'package:jackdigitalstore_app/model/general_settings/general_settings_model.dart';
import 'package:jackdigitalstore_app/provider/home_provider.dart';
import 'package:jackdigitalstore_app/session/session.dart';
import 'package:jackdigitalstore_app/utils/shared.dart';
import 'package:showcaseview/showcaseview.dart';

import '../pages.dart';

class IntroScreen extends StatefulWidget {
  final List<GeneralSettingsModel>? intro;
  IntroScreen({Key? key, this.intro}) : super(key: key);

  @override
  _IntroScreenState createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> {
  final introKey = GlobalKey<IntroductionScreenState>();

  Widget titleWidget(String title, String _image) {
    return Container(
      child: Column(
        children: [
          Padding(padding: EdgeInsets.only(top: 40.0)),
          Container(
            child: Image.network(
              _image,
              errorBuilder: (BuildContext context, Object exception,
                  StackTrace? stackTrace) {
                return Icon(
                  Icons.broken_image_outlined,
                  size: 128,
                );
              },
            ),
          ),
          // Padding(padding: EdgeInsets.only(top: 20.0)),
          Align(
            alignment: Alignment.center,
            child: AutoSizeText(
              title,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w700,
              ),
              maxLines: 1,
              minFontSize: 18,
              textAlign: TextAlign.center,
            ),
          )
        ],
      ),
    );
  }

  void _openHome(context) {
    Session.data.setBool('isIntro', true);
    if (!Session.data.containsKey('tool_tip')) {
      Session.data.setBool('tool_tip', true);
    }
    if (Provider.of<HomeProvider>(context, listen: false).toolTip) {
      Session.data.setBool('tool_tip', true);
    }
    Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (BuildContext context) =>
                ShowCaseWidget(builder: Builder(builder: (context) {
                  return HomeScreen();
                }))));
  }

  @override
  Widget build(BuildContext context) {
    const bodyStyle = TextStyle(fontSize: 18.0);
    const pageDecoration = const PageDecoration(
      bodyTextStyle: bodyStyle,
      bodyPadding: EdgeInsets.fromLTRB(16.0, 10.0, 16.0, 10.0),
      pageColor: Colors.white,
    );
    return IntroductionScreen(
      key: introKey,
      pages: [
        for (var i = 0; i < widget.intro!.length; i++)
          PageViewModel(
            titleWidget:
                titleWidget(widget.intro![i].title!, widget.intro![i].image!),
            decoration: pageDecoration,
            bodyWidget: Text(
              widget.intro![i].description!,
              textAlign: TextAlign.center,
            ),
          ),
      ],
      onDone: () => _openHome(context),
      showNextButton: true,
      showSkipButton: true,
      nextFlex: 0,
      skipOrBackFlex: 0,
      globalBackgroundColor: Colors.white,
      skip: Text(
        AppLocalizations.of(context)!.translate('skip')!,
        style: TextStyle(color: accentColor),
      ),
      next: Text(AppLocalizations.of(context)!.translate('next')!,
          style: TextStyle(color: accentColor)),
      done: Text(AppLocalizations.of(context)!.translate('done')!,
          style: TextStyle(fontWeight: FontWeight.w600, color: accentColor)),
      dotsDecorator: DotsDecorator(
        size: Size(10.0, 10.0),
        activeColor: accentColor,
        activeSize: Size(22.0, 10.0),
        activeShape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(25.0)),
        ),
      ),
    );
  }
}
