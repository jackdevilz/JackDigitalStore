import 'package:jackdigitalstore_app/utils/globalURL.dart';
import 'package:jackdigitalstore_app/utils/utility.dart';

class AuthAPI {
  loginByDefault(String? username, String? password) async {
    Map data = {'username': username, 'password': password};
    var response = await baseAPI.postAsync(
      '$loginDefault',
      data,
      isCustom: true,
    );
    return response;
  }

  loginByOTP(phone) async {
    var response =
        await baseAPI.getAsync('$signInOTP?phone=$phone', isCustom: true);
    return response;
  }

  sendEmailForgots(String? email) async {
    Map data = {'email': email};
    var response =
        await baseAPI.postAsync('$sendEmailForgot', data, isCustom: true);
    printLog("response : ${response}");
    return response;
  }

  checkPassKey(String? key, String? id) async {
    Map data = {'id': id, 'key': key};
    var response =
        await baseAPI.postAsync('$checkPasswordKey', data, isCustom: true);
    printLog("Pas Key : ${response}");
    return response;
  }

  resetPasswords(String? id, String? password, String? key) async {
    Map data = {'id': id, 'new_password': password, 'key': key};
    var response =
        await baseAPI.postAsync('$resetPassword', data, isCustom: true);
    printLog("Reset : ${response}");
    return response;
  }
}
